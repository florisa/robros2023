# MNIST > 2023-02-01 11:35pm
https://universe.roboflow.com/mnist-bvalq/mnist-icrul

Provided by a Roboflow user
License: CC BY 4.0

